<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Theatres de Bourbon</title>
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
  </head>
  <body>

<!-- ce qei ressemble à l'entête plus le petit panier à droite-->

<div class="bandeau">
	<div class="petitPanier">
		<table>
			Billets en vente exclusivement sur les lieux du festival: Monétay, Monteignet, Veauce  du 2 au 6 août dès 11h00 et le 6 août à Moulins de 19h00 à 20h00.
									Attention! à Moulins le début du spectacle à 20h00.
	</table>
	</div>
										<h1> Festival Théâtres de Bourbon </h1>
</div>

<!-- le menu à gauche -->
	<div class="menu">
			<ul>
					<h3> le site</h3>
					<li> qui sommes nous ?</li>
					<li><a href="getSpectacles.php">jour par jour</a></li>
					<li><a href="parLieux.php"> lieu par lieu</a></li>
          <li><a href="troupes.php"> troupes par troupes</a></li>
					<li> spectacles </li>
					<li>tarifs</li>
			</ul>
			<ul>

					<li>le festival </li>
					<li> carte blanche </li>
					<li> l'association </li>
					<li> devinir membre </li>
					<li> faire un don</li>
					<li> nous contacter</li>
		  </ul>
  </div>
<!-- fin index.html-->

<main>
	<div class="decalage">

<?php
  if( ($handle = fopen("ResultatsFestival.csv","r")) !== FALSE ){
    fgetcsv($handle,1000,",");
    $cptLine = 1;
    //hashmap string -> array of string
    $sousTableau = [];
    while ( ($allDate = fgetcsv($handle,1000,"\n")) !== FALSE ) {

      foreach ($allDate as $lines) {
        $replaced = preg_replace_callback(
          '/"(\\\\[\\\\"]|[^\\\\"])*"/',
            function($match){
            $tempo = preg_replace("[,]",'&#44;',$match);
            implode($tempo);
            return $tempo[0];
          } ,
          $lines
        );
          $fields = preg_split("[,]",$replaced);


          //former if places
/*
          if(  ! in_array($fields[3],$sousTableau) ){
            //if unseen city, create a new map for it
            $sousTableau[ $fields[3] ]=[];
          }*/
          //putt the whole line deragmented into the hasmap city -> lines, delim = ","

          $sousTableau[$fields[5]] [] = $fields;
          //array_push($sousTableau[$fields[3]],$fields);
          //former fields
      }




    }//end of while fgetcsv

    ksort($sousTableau);
    //show hashmap
    foreach ($sousTableau as $compagnie => $lines) {
      echo "<h2>".$compagnie."</h2>\n";
      foreach ($lines as $fields) {
        
        $jour = $fields[0];
        $horaire = $fields[1];
        $titre = $fields[2];
        $ville = $fields[3];
        $village = $fields[4];


        print("<p> <jour> ". $jour. "</jour>, <horaire>". $horaire . "</horaire> , <lieu> au " . $ville . " à " . $village . "</lieu>, <titrespectacle>". $titre ."</titrespectacle> \n");
        print('<form action ="resa.php" method="GET"><input type="submit" value="Réserver"/><input type="hidden" name="line" value="'.$cptLine.'"/></form></p>');
        $cptLine++;
      }//end of foreach $city

    }//end of foreach $sousTableau

  }else{
    echo "le fchier n'a pas pu être ouvert par fopen";
  }//fin if fopen
?>

</div>
</main>
</body>
</html>
